import { ColorValue, GestureResponderEvent, ImageSourcePropType, StyleProp, ViewStyle } from 'react-native';
import { ReactProps } from './React';

export interface CreditCardProps {
    width?: number,
    height?: number,
    number: number,
    name: string,
    expiry: string,
    shiny?: boolean,
    type: 'visa' | 'mastercard',
    backgroundColor?: ColorValue,
    backgroundImage: ImageSourcePropType
    style?: StyleProp<ViewStyle>
}

export interface CustomTouchableProps {
    handlerPress?: () => void,
    style?: StyleProp<ViewStyle>,
    title: string
}

export interface ImageContainerProps extends ReactProps {
    style?: StyleProp<ViewStyle>
}

export interface SpaceProps {
    height: string | number
}

export interface TouchableIconProps {
    name: string;
    color?: string;
    size?: number;
    onPress?: (event: GestureResponderEvent) => void;
}
