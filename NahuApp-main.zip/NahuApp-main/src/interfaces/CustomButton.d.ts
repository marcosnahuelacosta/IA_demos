export interface CustomButtonProps {
    title: string,
    iconName: string,
    color?: ColorValue
}
