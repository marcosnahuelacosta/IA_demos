import { ImageSourcePropType } from 'react-native';

export interface PayoutProps {
    title: string,
    bodyText: string,
    price: number,
    date: Date,
    source: ImageSourcePropType
}
