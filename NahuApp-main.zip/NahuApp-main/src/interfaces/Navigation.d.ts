import { NativeStackScreenProps } from '@react-navigation/native-stack';

export type StackRoot = {
    'Login': undefined;
    'Tabs': undefined;
}

export type StackHome = {
    'Home': undefined;
    'Load': undefined;
    'USDT': undefined;
    'Bancaria': undefined;
    'Efectivo': undefined;
}

export type StackUser = {
    'User': undefined;
    'Settings': undefined;
}

export interface Props extends NativeStackScreenProps<StackRoot, any> { }
export interface HomeStackProps extends NativeStackScreenProps<StackHome, any> { }
export interface UserStackProps extends NativeStackScreenProps<StackUser, any> { }
