export interface ReactProps {
    children?: React.ReactNode
}
