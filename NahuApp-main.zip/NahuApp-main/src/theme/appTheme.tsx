import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
    globalMargin: {
        marginHorizontal: 20,
    },
    containe: {
        flex: 1,
        backgroundColor: 'black',
    },
    bigBtn: {
        width: 100,
        height: 100,
        backgroundColor: 'red',
        borderRadius: 20,
        alignItems: 'center',
        justifyContent: 'center',
        margin: 10,
    },
    textBigBtn: {
        color: 'white',
        fontSize: 20,
        fontWeight: 'bold',
    },
    avatar: {
        width: 150,
        height: 150,
        borderRadius: 100,
    },
    avatarContainer: {
        flex: 1,
        alignItems: 'center',
        marginTop: 10,
    },
    menuContainer:{
        flex: 1,
        alignItems: 'center',
        backgroundColor: 'cyan',
        marginTop: 20,
    },
    option: {
        marginVertical: 10,
    },
    textOption: {
        fontSize: 25,
        color: 'black',
        left: 5,
    },
});
