import React from 'react';
import { View } from 'react-native';
import { SpaceProps } from '../interfaces/Components';

export const Space = ({ height }: SpaceProps) => {
    return (
        <View style={{ height }} />
    );
};
