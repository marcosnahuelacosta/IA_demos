import React from 'react';
import { View, StyleSheet } from 'react-native';
import { ImageContainerProps } from '../interfaces/Components';

export const ImageContainer = ({ children }: ImageContainerProps) => {
    return (
        <View style={{ ...styles.imageContainer }}>{children}</View>
    );
};

const styles = StyleSheet.create({
    imageContainer: {
        backgroundColor: 'white',
        borderRadius: 50,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 4,
        },
        shadowOpacity: 0.30,
        shadowRadius: 4.65,
        elevation: 8,
        justifyContent: 'center',
        alignItems: 'center',
    },
});
