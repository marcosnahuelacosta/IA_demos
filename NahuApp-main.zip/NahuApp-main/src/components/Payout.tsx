import React from 'react';
import { StyleSheet, View, Text, Image } from 'react-native';
import { PayoutProps } from '../interfaces/Payout';
import { ImageContainer } from './ImageContainer';

export const Payout = ({ bodyText, date, price, title, source }: PayoutProps) => {
  return (
    <View style={styles.container}>
      <View style={styles.imageContainer}>
        <ImageContainer>
          <Image source={source} style={styles.image} />
        </ImageContainer>
        <View style={styles.detailsContainer}>
          <Text style={styles.title}>{title}</Text>
          <Text style={styles.body}>{bodyText}</Text>
        </View>
      </View>
      <View style={styles.priceContainer}>
        <Text style={styles.price}>$ {price.toString().replace('.', ',')}</Text>
        <Text style={styles.date}>{`${date.getHours()}:${date.getMinutes()}`}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    // backgroundColor: '#c9c9c9',
    width: '100%',
    padding: 8,
  },
  imageContainer: {
    flexDirection: 'row',
  },
  image: {
    width: 60,
    height: 60,
    backgroundColor: '#FFF',
    borderRadius: 50,
  },
  detailsContainer: {
    marginLeft: 20,
    justifyContent: 'center',
  },
  title: {
    color: 'black',
    fontSize: 16,
  },
  body: {
    color: 'grey',
    fontSize: 14,
  },
  priceContainer: {
    alignItems: 'flex-end',
  },
  price: {
    color: '#66FF77',
    fontWeight: 'bold',
  },
  date: {
    color: 'grey',
  },
});
