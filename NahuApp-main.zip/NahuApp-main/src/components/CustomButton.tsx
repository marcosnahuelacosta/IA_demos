import React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { TouchableIcon } from './TouchableIcon';
import { CustomButtonProps } from '../interfaces/CustomButton';

export const CustomButton = ({ title, iconName, color = '#50b1e2' }: CustomButtonProps) => {
    return (
        <View style={styles.container}>
            <TouchableIcon name={iconName} color={color} onPress={() => console.log(title)} />
            <Text style={styles.text}>{title}</Text>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        width: 70,
        alignItems: 'center',
        margin: 10,
    },
    icon: {
        margin: 10,
    },
    text: {
        color: 'black',
        marginTop: 5,
        textAlign: 'center',
        fontSize: 12,
    },
});
