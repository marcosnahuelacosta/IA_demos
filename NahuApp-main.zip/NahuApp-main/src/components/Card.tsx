import React from 'react';
import { View, StyleSheet, useWindowDimensions, StyleProp, ViewStyle } from 'react-native';
import { ReactProps } from '../interfaces/React';

interface Props extends ReactProps {
    style?: StyleProp<ViewStyle>
}

export const Card = ({ children, style = {} }: Props) => {

    const { width: widthD } = useWindowDimensions();

    return (
        <View style={{ ...styles.container, width: widthD - 20, ...style as ViewStyle }}>{children}</View>
    );
};

const styles = StyleSheet.create({
    container: {
        backgroundColor: 'white',
        borderRadius: 5,
        flexWrap: 'wrap',
        flexDirection: 'row',
        alignItems: 'baseline',
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 4,
        },
        shadowOpacity: 0.30,
        shadowRadius: 4.65,

        elevation: 8,

    },
});
