import React from 'react';
import { Text, TouchableOpacity, StyleSheet, ViewStyle } from 'react-native';
import { CustomTouchableProps } from '../interfaces/Components';

export const CustomTouchable = ({ handlerPress, title, style }: CustomTouchableProps) => {

    return (
        <TouchableOpacity
            style={{ ...styles.touchable, ...style as ViewStyle }}
            onPress={handlerPress}
        >
            <Text style={styles.text}>{title}</Text>
        </TouchableOpacity>
    );
};

const styles = StyleSheet.create({
    touchable: {
        backgroundColor: '#6537eb',
        padding: 10,
        marginTop: 25,
        borderRadius: 5,
        alignItems: 'center',
    },
    text: {
        color: 'white',
        fontSize: 16,
    },
});
