import React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';
import { CreditCardProps } from '../interfaces/Components';

const images = {
    'visa': 'data:image/gif;base64,R0lGODlhOQAjAPcAAABEjGagzdqIAAAofNNuAJq/0zl+rwBJkABZlgASbgBQkyJupgAsgAA6hwBGjdmDAE2LtzN7rXOlx85lAABjngBJjgAzggAqfABSlNmGAAAZcgBUlQBCjIezzQBcnAA3hQAneQA1gwAWcQA4hQBenAAfdgAgdAAtfgBAiQA8hgA9iABamQBZmwBXmABWlgAwgABNkgAieAA+iQBZmABQlABOlABMkQAOaxNnnmWdwmadw22hxduMAxNnn2afzGaexgBBimmfxABVlgBVl7fR4diEANV5AP///AA0gW6ixWai0f///tJ1AABCiuOxVgBKjgBUlmaex9mFAABAipi91ZC2z3qoyWqfxABKjdzn8QAIaJS70wBgnafI29yOAy52qpG80tfp7cHb5pK60zSArWyfwQBSlvj9/QAXbwBEi16YvfH5+v3+/tZ7AKDC1dLg6Rlro2Wew3qqyfX4+ESGtKbF2gtinI+40gAFZd+mRFSTu6zK34i10NmEANNxAE+OuXWryABGjvz/+f3//XikxwAsehRon5i/0xRooOCtUe/0+WygxmyixGyixtjo7GWcvhRnn+GrRghdm93r8Yixy4qxzsje52aeyHOiwfD3+I620Orx9O709mObwJ3E3IWzzwAbdEuJswBhoHKoyM9sAABbm7DM2rLM27PP2+GuTG+kxPP4+vz8/Zi909/o74i1zwBUkT+Fsg9inGacxD2AtJ6+1T+EtBxrowA5hZS90oCvyoWuylORux9updvn7nyoyUKDs+Tu9EGFsefw8wBRlmacwkuMtjZ9rwAxgSl1psTZ5MTY5whhnGadwYy60VqSul2VvGiexGmexXepx73U5LzW5gA6iNmBAFqYvdnn6/v8/q7M3/X6+Za61Yu20GWcwtBxAPr8+dNyAJe+1k+NuVWRusfd6FaSu/H399Dg6lCRuQBem0yJtXeryU2PuP///eOwVdV2ANJ0ANuLAwBKjwBUl9uJAABdm9yNAwBOkmai0ABcm5q+1tuLAgBbmv///yH5BAAAAAAALAAAAAA5ACMAAAj/AMkRocKvoMGDCBMqXMgwIRUif3b8m0ixosWLGDNq3Lij0T8gNYbUG0mypMmTKFOqHDnkAIZ/0ZL8++BAQb6bOHPq3Mmzp8+bCoA4+HdFogMh9/YpXcq0qdOnUKMqJaEAyr8gEgFs2Oevq9evYMOKHUu26758G65m3Vq2rdu3/s6mxfovENJ7ePPq3cu3r9+/eKlaDSLTQhN6iBMrXsy4sePHiW2oAEJ00T9YzCDh2IyjB2fOnj93Fh1aNGjTog35k/VP2reNsGPL1vhNh8Zs1c5oy3TE4plJ/waxyTRnIrdcowB1uTiI1ZrYOWxnPPJMQwM05Sp+SKDgH6gRN9L9/3sE4oKIBBpifKHoynqCPbCjw0aQrwE2iuyQXfjXDcnNf9CU0IICznhCxg21UISBA+tY0Ep80mkEBz1AGDPRJhcwsMs/ksDQACH/gHAPEllQ1NtEVVxQAwm4/AIhbAscwAEdE7lggRkThVDKCe9kcYEoMnRS0RI5coAJMSno8eJGEQDgQAT/pMgAOv9sYUFLExVSAwXIJGMRMBpA8E8IAByzpEbCcAAALTMx8MhECzgwBTsTWRLDFBSocAE1EwVT3j+rIHHALWdmxMsUFahRxgVPUGSNPy8sUxEzFlBAgwmC/CPEAHdMhIsN/hSKURwpeDADDAP4MtE2FrTQxEW6qP/AxQn/EHEBDL0gYseAMIh6kRW4kOCBBaFQZEAaQBjwjykVKYIECzL8A4BWB6CABQtCULaRfBtR0gAFGKRQkQMrWGDOP3hgAEYY4zzRQgma8DHAARWh0IIMRGrErUaV3DBCAspQVIcWyJTwDyolgCCCCBqcMAAjnGiRgBgVxXDCDW9sG2FGjgDySgEVndJOB25QNIY67pzzSTj/FKDKIRZ14M00w2xbzGw457xRM5f8k0cqTsAj9NBEwxN00UgnrbTSTkSSyD+zBPDPBH7EY/XVWGet9dZcd401AeL8E4UP/7QhAD5op6322my37fbbaXshhRT//EC2ERnw0M/efPd27fffgAcu+N48PFBE3XfnPfjijDfeT+GH2/0P3jzMY/nlmGeu+eacd2455Ij/E08f9pRu+umop6766qyffs0DdUs9AQFMyGP77bjnrvvuvPduOxOkgCO2BDoXb/w/Etgihz5K6OP889BHL/301FcPvRIBWBFLQAA7',
    'mastercard': 'data:image/gif;base64,R0lGODlhOQAjAPcAAPnZ2bBzPhIScWhysMkAAPHFzCwvhedoAPLb4/NzAJim2v/Iuf2DAP/MAP/+5OmUlM82AHpol5VZKWgBKwAAgtj//9wAANrs/00AAlsyO1QAOgAAZEwrQ64qAJqIqxgvsbwAASyO7P/TAP+MAP+9APsAAP+pANIAAP+dAKEdNJRrjHgiSv+WAAAAeueEg/+lAP+tABVEvwAAbP+yAP+gAAoAWfX9/8hZAP+5AP3apwAAc/+aAP6lGZgAAPrmy80AAOb//3iX+go0wcQAAP/BAIWo//+1AP9+AP+uO69PAJyx/emJCPHs6vv//xYWe3UAAfmbGorI/vFsAP66Vcl3FWM6PeMAAMvJ2rRqHf/EADcASv+RALm83k8PSPoZA/xyAPR8AOwAANtpAMAAAMLC1qgAAIpULosAHRYWg/aMAP/xAAAFlycWVqq43PIAADAAABAAANUYAP+UAIQAALQAAFxuyQgAMpQAGv/69qgAEMv//wgDYmMAAP9vAN88ADshTM4KAM4EAP+YAAsLbf/jAMywwetEAOYuJeXp/wAIdqlCVnpVVJPV/84MDMzO1s7c89jR4Uxw0npYYDZdt//aPOlRAL80QX4AEIG/+py97sKXbcMZIF9cj3yMxKu+484FBtEVE10lYHg/aeTP0aZ0seePjXO3+fCEgaiqz6Ov0qLd//uRAP+PevuXBZ4nAHY2ANne///RvNEKAP/ETTpJkc+nhIR9sf/pm8sAB1UmGbi00aNgJPJXAP+3GDc+U83P5ItJaotpbf/Rg6F0WfSTl1pHdXZgc//wyP/83ZqKmuWOJOby/yUfcHlGNNZxANLJ2+R2AP/rp//mtv//srMACpaYwpzD/4RNMB8AU8fQ8e/p7DwMVfKiLP2xPf7EcdlCP8Pt/93Z4dfl7NXS4sh6IdHV7P6YAv8kENxQUP9mT6ecv11+w+D5/25OgrS421xvs2taf4EAPHZDcyRTrCNevhMIXDVTpn6s4v/aIxsQZxYWc/8AAP///wAAZv+ZAMwAACH5BAAAAAAALAAAAAA5ACMAAAj/AA0M0kewoEGCTtAoVOjEycGHCBcydAjR4CADAvpp3KhxwwYdFFps0KKhpJYaIFv028DRY0oZf6rIzMDmJUuOHAXow9kRZI0zFkoIFbpvn5U8WkKuXAmynwQUOEhInWpkSRWQMm7iJIhzgwwKe0DsK2HhB4GzZ/+dCLPPQtKsFGRQIULCxA5/LPKy2IECRhYczSjo0LqR60avFCbsC5P2n+PHjs9a2AdCx5oMf3ewEOSvs+fOeWlkedGPAuF+hplSGLPvHwHIsCETGFICxK4GKFh83v1ZEAsYDf6Y5mgY8Yl9Q2Irf/xjzBE1JGjo5k0dLw0RwrWmpkAN+fLlZgn4/4kji4YJztV5s6DRoJ5IjVw3UNDg/Xtss0MIgBhD59+Mu+mpZ8IMLcgAnz4fybDPCfYpN5sJIhCRRRYwGIECegF+xgIRuwxHkHxnlPBag7AREAcLCaSYohR2ZcgbCiTIkBVBMuhQAoM/OPbDjvaZBQIdQAZZRiU47LXDkS5uKIFpBLVAHwFjjEFAc2MMkWOOzDk2RCAMJCCFl1JIcUACJvjDwBFHjHAkgP6w6Q8KI4zwgkoEUZBHGKA8UMoJP5TyADr5nbUjWhaAYIgaDcxgRAMNTIgDDQxMcYw03YywxRaCaKaXIHJsMUUOJNSjQ5NWnDAAP/xYIAqqp4Dwzyf55f/XCAGK8PMNCCDgMgQIDPJ6gzj8NMGPA32Y0woDvsW5wxEwdGANPzBk0II+TvRTAh0KoEpHG6hugiqq/zyAKgDtoDpEAagS0wMQeCAQCT/h5JKPMt/ycwAsw0KBqiMXOICCBNM6scE+c4BjAz8rsOMOP10MoMWpKvADiQEpqMOPCqXws00n/ExQAT/3cMHPETQYkUEdHJw6TDb8cHEFP3Usw08OKGBBAbUDP2EDKuO0cUUq/NCxyQJk8DMJP3ic8IQe/PABBD+HVMNPKPwAAMewRwjyAhjcTFN0ME0wYQc/t3RgAD/e0GAzzvtMwE8Ev/ADDBALuMAPJnFjQA+qK1T/sAAG/NigBxCQyMNPOhg0gcwXKPrATxDl8CMJP7Mswg8SR3By+QtrOyFDCVSv8EjH/HhA9xuZ8LMPBhvw4wk/rLzBzygY8PGEB/ycA8fHPGwRABDRPKEEP8bww0Mx/AhzwAX8bGGCGdPq08IQtvBzCRCxuE0L86gioM2376CqwjrfMqELP1b0IMS3RSDyrQ/J8DPD2PVCgQ8H0bfwxDyF9BCCF8yIwgkSwYgI2CMC9IiCKSyBgRCowgtviEERihCPGJCCACV4xRqKoARy6KAIEfiAJj5QDRI4gwJBgIcQatELStQANdLTQhjKYIEynGAMPQjDGObwjzIMoQxz6MFa/4L4gz5AwBUdMAQEIMALKYgADEm4AQzSkIQtiIEB0DjADmYghxuMQAxgMEEa6KQPGbSgBFb4hwUIYIE1WqBUFjiBFaxQlh/QcQyrIASjGCUCHMCABS+AgQkACQPzmOcFvqFBIe2ShSqI5EOJ2ceIZEPJyGhpCFGKEggIYIQdCOKT/gAlZ0AZSs4A8gVxgWE/zBiGNZKoRICIww8CEYghMAAGGHIRXogggVWqcgMtwEZrXimbHxBCDYQQQV2mo0t/yIEEVGCDGQZTnEg25pU/2JIfAOGHGTBTl78xgg5aMBhVboQCZ2jNJF85hKC8gAa5zBALZhCj9xzoMF9RjCtJRLqA45zBFyL4YzypsxkimGCchEnNObHBljWu8zGCKsE+NEABCvQDBQ0Y5GZy6RvdzKABNisncXbSlRYkhi1uiOOOfnACC7ClBHf4imo48IK/mIAGa0KBIklAhCXsIS6nMWdXvtICLdxhLUNJaR408BWRsiQkbNiFIGBAAhxY1QRLuIZ8RMoTfWSEJx0xY0hksIcN7KEfJi2QR7rSj5fs4a1tDclggroRAQikIgdpiF7xChG97pWvBLlIQAAAOw==',
};

export const CreditCard = ({
    width = 300,
    height = 180,
    backgroundColor = '#191278',
    expiry,
    name,
    number,
    type,
    shiny = false,
    backgroundImage,
    style,
}: CreditCardProps) => {

    const cardStyle = [styles.container, { width, height, backgroundColor }, style];

    return (
        <View style={cardStyle}>
            <View style={[styles.front, { width, height }]}>

                {backgroundImage && <Image source={backgroundImage} style={[styles.bgImage, { width, height }]} />}

                <View style={styles.lower}>

                    {shiny && <View style={styles.shinyFront} />}

                    <Image
                        style={styles.logo}
                        source={{ uri: images[type] ?? images.mastercard }}
                    />
                    <View style={styles.info}>
                        <View>
                            <Text style={styles.textNumber}>{number}</Text>
                        </View>
                        <View style={styles.rowWrap}>
                            <View style={styles.name}>
                                <Text style={styles.textName}>{name}</Text>
                            </View>
                            <View style={styles.validthru}>
                                <Text style={styles.textValidThru}>VALID THRU</Text>
                            </View>
                            <View style={styles.expiry}>
                                <Text style={styles.textSmall}>MONTH/YEAR</Text>
                                <Text style={styles.textExpiry}>{expiry}</Text>
                            </View>
                        </View>
                    </View>
                </View>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        borderRadius: 8,
    },
    logo: {
        height: 35,
        width: 57,
        position: 'absolute',
        top: 20,
        right: 20,
    },
    text: {
        color: '#fff',
    },
    bgImage: {
        position: 'absolute',
        left: 0,
        top: 0,
        bottom: 0,
        right: 0,
        borderRadius: 8,
    },
    lower: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-end',
        paddingVertical: 20,
        paddingHorizontal: 20,
    },
    expiry: {
        flex: 1,
        alignItems: 'flex-end',
        justifyContent: 'center',
    },
    rowWrap: {
        flexDirection: 'row',
    },
    name: {
        flex: 2,
        justifyContent: 'center',
    },
    validthru: {
        flex: 1,
        alignItems: 'flex-end',
        justifyContent: 'center',
    },
    textValidThru: {
        fontSize: 8,
        color: '#ddd',
        fontWeight: '900',
        backgroundColor: 'transparent',
    },
    textSmall: {
        fontSize: 8,
        color: '#ddd',
        fontWeight: '900',
        backgroundColor: 'transparent',
    },
    textNumber: {
        color: '#fff',
        fontSize: 22,
        textAlign: 'center',
        marginBottom: 10,
        backgroundColor: 'transparent',
    },
    textName: {
        color: '#fff',
        fontSize: 14,
        backgroundColor: 'transparent',
    },
    textExpiry: {
        color: '#fff',
        fontSize: 16,
        backgroundColor: 'transparent',
    },
    front: {
        flex: 1,
    },
    back: {
        flex: 1,
    },
    textCvc: {
        color: '#000',
        fontSize: 18,
    },
    info: {
        flex: 1,
    },
    shinyFront: {
        backgroundColor: '#ddd',
        borderRadius: 8,
        width: 50,
        height: 40,
        position: 'absolute',
        top: 15,
        left: 20,
    },
    shinyBack: {
        backgroundColor: '#ddd',
        borderRadius: 8,
        width: 50,
        height: 40,
        position: 'absolute',
        bottom: 15,
        left: 20,
    },
    bar: {
        height: 40,
        position: 'absolute',
        left: 0,
        right: 0,
        top: 30,
        backgroundColor: '#000',
    },
});
