import React from 'react';
import { StyleSheet, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import { ImageContainer } from './ImageContainer';
import { TouchableIconProps } from '../interfaces/Components';

export const TouchableIcon = ({ name, size = 40, color = '#900', onPress }: TouchableIconProps) => {

    return (
        <TouchableOpacity onPress={onPress} activeOpacity={0.7}>
            <ImageContainer>
                <Icon name={name} size={size} color={color} style={styles.icon} />
            </ImageContainer>
        </TouchableOpacity >
    );
};

const styles = StyleSheet.create({
    icon: {
        margin: 12,
    },
});
