import { CustomButtonProps } from '../interfaces/CustomButton';

export const buttons: CustomButtonProps[] = [
    {
        title: 'Recargar celular',
        iconName: 'phone-portrait-outline',
    },
    {
        title: 'Cuentas y servicios',
        iconName: 'document-text-outline',
    },
    {
        title: 'Cargar Transporte',
        iconName: 'bus-outline',
    },
    {
        title: 'Beneficios',
        iconName: 'menu-outline',
        color: '#8556b6',
    },
    {
        title: 'Cobrar con Point',
        iconName: 'card-outline',
        color: '#525ebd',
    },
    {
        title: 'Cobrar con link de pago',
        iconName: 'link-outline',
        color: '#525ebd',
    },
    {
        title: 'Invitá y ganá',
        iconName: 'gift-outline',
        color: '#dc9f1e',
    },
    {
        title: 'Ver más',
        iconName: 'add-outline',
        color: '#5d5d5d',
    },
];
