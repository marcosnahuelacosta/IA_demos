import { PayoutProps } from '../interfaces/Payout';

export const payouts: PayoutProps[] = [
    {
        title: 'Transferencia enviada',
        bodyText: 'Mercado Libre',
        price: 432423.22,
        date: new Date(),
        source: { uri: 'https://pps.whatsapp.net/v/t61.24694-24/310855267_161187993212333_2347048431198773962_n.jpg?ccb=11-4&oh=01_AdQHYyqBO5ouHHOYgKqVMYlx8nXT8XybQWP4byQx6jbx3Q&oe=643C2D1C' },
    },
    {
        title: 'Transferencia enviada',
        bodyText: 'Amazon',
        price: 10000,
        date: new Date(),
        source: { uri: 'https://pps.whatsapp.net/v/t61.24694-24/61481025_317691649167551_6281434767556608000_n.jpg?ccb=11-4&oh=01_AdRT3JYnriQ_vaLD1Ggldhhgn0ccXDa3hfOknJYb_f5Txg&oe=643C1036' },
    },
    {
        title: 'Transferencia reciboda',
        bodyText: 'de JULIAN PEREZ',
        price: 99,
        date: new Date(),
        source: { uri: 'https://pps.whatsapp.net/v/t61.24694-24/311563489_658307345839059_2489688490082841514_n.jpg?ccb=11-4&oh=01_AdTWR69kaUldbPQwI7VAkHc-XsvROFcvsngp3oMAKrKejQ&oe=643C2F58' },
    },
    {
        title: 'Transferencia reciboda',
        bodyText: 'de JULIAN PEREZ',
        price: 99,
        date: new Date(),
        source: { uri: 'https://pps.whatsapp.net/v/t61.24694-24/328067891_543459551215296_2654550269500607756_n.jpg?ccb=11-4&oh=01_AdSqWOhu6ciIE6yQKZ-32uMQhG-tV7PQEDMRactZPiMFag&oe=643C37D0' },
    },
];
