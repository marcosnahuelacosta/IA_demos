import { useContext, useEffect, useState } from 'react';
import { ColorValue } from 'react-native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { UserContext, UserData } from '../context/UserContext';
import { StackRoot } from '../interfaces/Navigation';
interface InputColorState {
    username: ColorValue,
    password: ColorValue
}

export const useLogin = (navigation: NativeStackNavigationProp<StackRoot, any, undefined>) => {
    const { logIn, userData: { password, username } } = useContext(UserContext);
    const [isLoading, setIsLoading] = useState(false);



    const [inputColors, setInputColors] = useState<InputColorState>({
        username: 'black',
        password: 'black',
    });

    useEffect(() => {
        if (username && password) {
            navigation.reset({ routes: [{ name: 'Tabs' }] });
        }
    }, [username, password, navigation]);

    const userInputHandler = (text: string) => {
        if (inputColors.username !== 'black') { setInputColors({ ...inputColors, username: 'black' }); }
        setDataInput({ username: text, password: dataInput!.password });
    };

    const passwordInputHandler = (text: string) => {
        if (inputColors.password !== 'black') { setInputColors({ ...inputColors, password: 'black' }); }
        setDataInput({ password: text, username: dataInput!.username });
    };

    const submitHandler = async () => {

        if (!dataInput.username && !dataInput.password) { return setInputColors({ username: '#F00', password: '#F00' }); }
        if (!dataInput.username) { return setInputColors({ ...inputColors, username: '#F00' }); }
        if (!dataInput.password) { return setInputColors({ ...inputColors, password: '#F00' }); }

        await logIn(dataInput);
        navigation.reset({ routes: [{ name: 'Tabs' }] });


    };

    const [dataInput, setDataInput] = useState<UserData>({} as UserData);

    return {
        inputColors,
        userInputHandler,
        passwordInputHandler,
        submitHandler,
        isLoading,
        setIsLoading,
    };
};
