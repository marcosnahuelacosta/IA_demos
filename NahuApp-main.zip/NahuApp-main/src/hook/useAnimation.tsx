import { useRef, useState } from 'react';
import { Animated } from 'react-native';

interface AnimatedProps {
    opacity?: number,
    position?: number
}

export const useAnimation = ({ opacity: opacityInput = 0, position: positionInput = 0 }: AnimatedProps) => {

    const opacity = useRef(new Animated.Value(opacityInput)).current;
    const position = useRef(new Animated.Value(positionInput)).current;

    const [isActive, setIsActive] = useState(false);

    const fadeIn = (duration: number = 500, callback?: Function) => {
        Animated.timing(
            opacity,
            {
                toValue: 1,
                duration,
                useNativeDriver: true,
            }
        ).start(() => callback ? callback() : null);

        setIsActive(!isActive);

    };

    const fadeOut = (callback?: Function) => {
        Animated.timing(
            opacity,
            {
                toValue: 0,
                duration: 300,
                useNativeDriver: true,
            }
        ).start(() => callback ? callback() : null);

        setIsActive(!isActive);
    };

    const startAnimation = (positionInit: number, duration: number = 300) => {
        position.setValue(positionInit);

        Animated.timing(
            position,
            {
                toValue: 0,
                duration,
                useNativeDriver: true,
            }
        ).start();
    };

    const endAnimation = (duration: number = 300) => {
        position.setValue(0);

        Animated.timing(
            position,
            {
                toValue: 0,
                duration,
                useNativeDriver: true,
            }
        ).start();
    };

    return {
        opacity,
        position,
        isActive,
        fadeIn,
        fadeOut,
        startAnimation,
        endAnimation,
    };
};
