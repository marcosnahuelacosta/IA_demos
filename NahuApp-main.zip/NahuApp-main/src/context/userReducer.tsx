import { UserData } from './UserContext';

type userAction =
    | { type: 'logIn', payload: UserData }
    | { type: 'logOut' }


export const userReducer = (_state: UserData, action: userAction): UserData => {
    switch (action.type) {
        case 'logIn':
            return {
                ...action.payload,
            };
        case 'logOut':
            return {
                username: null,
                password: null,
            };
    }
};
