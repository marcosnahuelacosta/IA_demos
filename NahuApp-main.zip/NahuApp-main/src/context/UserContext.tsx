import React, { createContext, useEffect, useReducer } from 'react';
import { ReactProps } from '../interfaces/React';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { userReducer } from './userReducer';

export interface UserData {
    username: string | null,
    password: string | null,
}

export interface UserContextProps {
    userData: UserData,
    logIn: (user: UserData) => any,
    logOut: () => Promise<void>

}

const initialState: UserData = {
    username: null,
    password: null,
};

export const UserContext = createContext<UserContextProps>({} as UserContextProps);

export const UserContextProvider = ({ children }: ReactProps) => {

    const [userData, dispatch] = useReducer(userReducer, initialState);

    const logIn = async (user: UserData) => {

        await AsyncStorage.setItem('userToken', JSON.stringify(user));
        dispatch({ type: 'logIn', payload: user });
    };

    const logOut = async () => {
        await AsyncStorage.removeItem('userToken');
        dispatch({ type: 'logOut' });
    };

    useEffect(() => {
        const getUserToken = async () => {
            const token = JSON.parse(await AsyncStorage.getItem('userToken') || '{}') as UserData;

            logIn(token);

        };
        getUserToken();
    }, []);

    return (
        <UserContext.Provider value={{ userData, logIn, logOut }}>
            {children}
        </UserContext.Provider>
    );
};
