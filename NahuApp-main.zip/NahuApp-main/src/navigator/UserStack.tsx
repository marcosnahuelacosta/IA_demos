import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StackUser } from '../interfaces/Navigation';
import { User } from '../screens/User.tab';
import { Settings } from '../screens/Settings.screen';

const Stack = createNativeStackNavigator<StackUser>();

export const UserStack = () => {

    return (
        <Stack.Navigator>
            <Stack.Screen name="User" component={User} options={{
                headerShown: false,
            }} />
            <Stack.Screen name="Settings" component={Settings} options={{ title: 'Configuración' }} />
        </Stack.Navigator>
    );
};
