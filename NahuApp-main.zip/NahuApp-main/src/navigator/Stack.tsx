import React, { useContext } from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Login } from '../screens/Login.screen';
import { StackRoot } from '../interfaces/Navigation';
import { UserContext } from '../context/UserContext';
import { Tabs } from './Tabs';
import { Image, View } from 'react-native';

const Stack = createNativeStackNavigator<StackRoot>();


export const StackNavigator = () => {

    const { userData: { password, username } } = useContext(UserContext);

    return (
        <Stack.Navigator
            initialRouteName={(password && username) ? 'Tabs' : 'Login'}
            screenOptions={{
                headerStyle: {
                    backgroundColor: '#6537eb',
                },
                header() {
                    return (
                        <View style={{ backgroundColor: '#6537eb', height: 75, justifyContent: 'center', alignItems: 'center' }}>
                            <Image source={{ uri: 'asset:/CryptoPagos.png' }} style={{ width: 200, height: 45 }} />
                        </View>
                    );
                },
            }}
        >
            <Stack.Screen name="Login" component={Login} options={{ headerShown: false }} />
            <Stack.Screen name="Tabs" component={Tabs} />
        </Stack.Navigator>
    );
};
