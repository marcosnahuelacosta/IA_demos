import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StackHome } from '../interfaces/Navigation';
import { Home } from '../screens/Home.tab';
import { Load } from '../screens/Load.screen';
import { USDT } from '../screens/USDT.screen';
import { Efectivo } from '../screens/Efectivo.screen';
import { Bancaria } from '../screens/Bancaria.screen';

const Stack = createNativeStackNavigator<StackHome>();

export const HomeStack = () => {

    return (
        <Stack.Navigator>
            <Stack.Screen name="Home" component={Home} options={{
                headerShown: false,
            }} />
            <Stack.Screen name="Load" component={Load} options={{ title: 'CARGAR FONDOS' }} />
            <Stack.Screen name="USDT" component={USDT} options={{ title: 'CARGAR desde WALLET' }} />
            <Stack.Screen name="Efectivo" component={Efectivo} options={{ title: 'CARGAR EN EFECTIVO' }} />
            <Stack.Screen name="Bancaria" component={Bancaria} options={{ title: 'TRANSFERENCIA BANCARIA' }} />
        </Stack.Navigator>
    );
};
