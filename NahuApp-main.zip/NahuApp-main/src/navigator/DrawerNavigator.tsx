import React from 'react';
import { Image, useWindowDimensions, TouchableOpacity, StyleSheet } from 'react-native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import Icon from 'react-native-vector-icons/Ionicons';
import { Settings } from '../screens/Settings.screen';
import { Tabs } from './Tabs';

type RootScreens = {
    Tabs: undefined;
    Settings: undefined
}

const Drawer = createDrawerNavigator<RootScreens>();

export const LateralMenu = () => {

    const { width: widthD } = useWindowDimensions();

    // useEffect(() => {
    //     stackNav.reset({
    //         index: 0,
    //         routes: {}
    //     });
    //     console.log('ola');

    // }, [stackNav]);


    return (
        <Drawer.Navigator
            screenOptions={
                ({ route }) => ({
                    headerTransparent: true,
                    drawerType: widthD >= 768 ? 'permanent' : 'front',
                    headerTitle: '',
                    drawerIcon: ({ color, size }) => {
                        switch (route.name) {
                            case 'Tabs':
                                return <Icon name="home-outline" size={size} color={color} />;
                            case 'Settings':
                                return <Icon name="settings-outline" size={size} color={color} />;
                        }
                    },
                    drawerActiveBackgroundColor: '#fff',
                    header: ({ navigation }) => (
                        <TouchableOpacity
                            style={styles.touchable}
                            activeOpacity={0.3}
                            onPress={() => navigation.openDrawer()}
                        >
                            <Image
                                source={{ uri: 'asset:/logo.png' }}
                                style={styles.image}
                            />
                        </TouchableOpacity>
                    ),
                })
            }
        >
            <Drawer.Screen name="Tabs" options={{ title: 'Home' }} component={Tabs} />
            <Drawer.Screen name="Settings" options={{ title: 'Settings' }} component={Settings} />
        </Drawer.Navigator>
    );
};

const styles = StyleSheet.create({
    touchable: {
        marginTop: 15,
        marginLeft: 15,
    },
    image: {
        width: 50,
        height: 50,
    },
});
