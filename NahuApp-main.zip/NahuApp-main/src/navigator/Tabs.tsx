import React from 'react';
import { Platform, StyleProp, ViewStyle } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createMaterialBottomTabNavigator } from '@react-navigation/material-bottom-tabs';
import Icon from 'react-native-vector-icons/Ionicons';
import { Tab2 } from '../screens/Tab2.tab';
import { HomeStack } from './HomeStack';
import { UserStack } from './UserStack';

type RootTabs = {
    Payouts: undefined
    Feed: undefined
    HomeTab: undefined
}

export const Tabs = () => {
    return Platform.OS === 'android' ? <TabsAndroid /> : <TabsIOS />;
};

const TabI = createBottomTabNavigator<RootTabs>();

const TabsIOS = () => {
    return (
        <TabI.Navigator
            sceneContainerStyle={background}
            screenOptions={
                ({ route }) => ({
                    headerShown: false,
                    tabBarActiveTintColor: 'green',
                    tabBarInactiveTintColor: 'blue',
                    tabBarInactiveBackgroundColor: 'yellow',
                    tabBarStyle: {
                        borderTopWidth: 0,
                        elevation: 0,
                    },
                    tabBarLabelStyle: {
                        fontSize: 16,
                    },
                    tabBarShowLabel: false,
                    tabBarIcon: ({ color, size }) => {
                        switch (route.name) {
                            case 'Feed':
                                return <Icon name="alert-circle-outline" size={size} color={color} />;
                            case 'HomeTab':
                                return <Icon name="home-outline" size={size} color={color} />;
                            case 'Payouts':
                                return <Icon name="book-mark-outline" size={size} color={color} />;
                        }
                    },
                })
            }
        >
            <TabI.Screen
                name="Payouts"
                component={HomeStack}

            />
            <TabI.Screen
                name="HomeTab"
                component={Tab2}

            />
            <TabI.Screen
                name="Feed"
                component={UserStack}

            />
        </TabI.Navigator >
    );
};


const TabA = createMaterialBottomTabNavigator<RootTabs>();

const TabsAndroid = () => {
    return (
        <TabA.Navigator
            sceneAnimationEnabled
            sceneAnimationType="shifting"
            barStyle={background}
            labeled={false}
            screenOptions={
                ({ route }) => ({
                    tabBarIcon: ({ color }) => {
                        switch (route.name) {
                            case 'Feed':
                                return <Icon name="person-outline" size={26} color={color} />;
                            case 'HomeTab':
                                return <Icon name="card-outline" size={26} color={color} />;
                            case 'Payouts':
                                return <Icon name="qr-code-outline" size={26} color={color} />;
                        }
                    },
                    tabBarColor: '#6537eb',
                })
            }

            activeColor="black"
            inactiveColor="white"
            initialRouteName="HomeTab"
        >
            <TabA.Screen
                name="HomeTab"
                component={HomeStack}
                options={{
                    // tabBarIcon: {}
                }}

            />

            <TabA.Screen
                name="Payouts"
                component={Tab2}
                options={{
                    // tabBarIcon: {}
                }}
            />
            <TabA.Screen
                name="Feed"
                component={UserStack}
                options={{
                    // tabBarIcon: ({ color }) => <Text style={{ color }}>C:</Text>
                }}
            />
        </TabA.Navigator >
    );
};

const background: StyleProp<ViewStyle> = {
    backgroundColor: '#6537eb',
};
