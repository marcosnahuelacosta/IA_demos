import React from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { Card } from '../components/Card';
import { CustomTouchable } from '../components/CustomTouchable';
import { HomeStackProps } from '../interfaces/Navigation';

export const Load = ({ navigation }: HomeStackProps) => {
    return (
        <View style={styles.container}>
            <Card style={{ flexDirection: 'column', flexWrap: 'nowrap', alignItems: 'stretch', padding: 20 }}>
                <Text style={{ fontSize: 14, color: 'black' }}>Cargá fondos mediante las siguientes opciones:</Text>
                <CustomTouchable title="USDT DESDE OTRA WALLET" handlerPress={() => navigation.navigate('USDT')} />
                <CustomTouchable title="TRANSFERENCIA BANCARIA" handlerPress={() => navigation.navigate('Bancaria')} />
                <CustomTouchable title="EFECTIVO" handlerPress={() => navigation.navigate('Efectivo')} />
            </Card>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
});
