import React from 'react';
import { StyleSheet, View, Image, Text, useWindowDimensions } from 'react-native';
import { CreditCard } from '../components/CreditCard';
import { Card } from '../components/Card';
import { HomeStackProps } from '../interfaces/Navigation';
import { CustomTouchable } from '../components/CustomTouchable';

export const Home = ({ navigation }: HomeStackProps) => {

    const { width: widthD } = useWindowDimensions();

    return (
        <View style={styles.container}>
            <CreditCard
                backgroundImage={require('../assets/imgs/card-front.png')}
                number={4234235235233344}
                type="visa"
                expiry="12/28"
                name="Carlos Binker"
            />

            <Card style={{ paddingHorizontal: 20, paddingVertical: 15, marginTop: 30, alignItems: 'stretch' }}>
                <Image source={{ uri: 'asset:/usdt.png' }} style={{ width: 60, height: 60 }} />
                <View style={{ marginLeft: 20 }}>
                    <Text style={{ fontSize: 28, color: 'black', fontWeight: 'bold' }}>Tether</Text>
                    <Text style={{ color: 'grey' }}>41.068 USDT</Text>
                </View>
            </Card>


            <Card style={{ paddingHorizontal: 20, paddingVertical: 15, marginTop: 30, alignItems: 'stretch' }}>
                <Image source={{ uri: 'asset:/cryptouyu.png' }} style={{ width: 60, height: 60 }} />
                <View style={{ marginLeft: 20 }}>
                    <Text style={{ fontSize: 28, color: 'black', fontWeight: 'bold' }}>CryptoPesos</Text>
                    <Text style={{ color: 'grey' }}>41.068 CryptoUYU</Text>
                </View>
            </Card>

            {/* <Card >

                <Button
                    title="CARGAR FONDOS"
                    color="#6537eb"

                />
            </Card> */}

            <CustomTouchable
                style={{ width: widthD - 20 }}
                title="CARGAR FONDOS"
                handlerPress={() => navigation.navigate('Load')}
            />

        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginTop: 30,
        alignItems: 'center',
        backgroundColor: 'white',
    },
});
