import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

export const USDT = () => {

    return (
        <View style={styles.container}>
            <Text>
                USDT
            </Text>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
});
