import React from 'react';
import { StyleSheet, Text, View, Image, TextInput, TouchableOpacity, useWindowDimensions, ActivityIndicator } from 'react-native';
import { Props } from '../interfaces/Navigation';
import { Space } from '../components/Space';
import { useLogin } from '../hook/useLogin';

export const Login = ({ navigation }: Props) => {

    const { height: heightD, width: widthD } = useWindowDimensions();
    const { inputColors, isLoading, userInputHandler, passwordInputHandler, submitHandler: logIn, setIsLoading } = useLogin(navigation);

    const handleSubmit = async () => {
        setIsLoading(true);
        await logIn();
        setIsLoading(false);
    };

    return (
        <View style={styles.container}>
            <Image source={{ uri: 'asset:/logo.png' }} style={styles.logo} />
            <View style={{ ...styles.form, width: widthD - 60, height: heightD - 250 }}>
                <Text style={styles.header}>Iniciar Sesion</Text>
                <View>
                    <View>
                        <Text style={{ ...styles.inputLabel, color: inputColors.username }}>{inputColors.username === 'black' ? 'Nombre de usuario o Email' : 'Se requiere un nombre de usuario'}</Text>
                        <TextInput
                            style={styles.usernameInput}
                            textContentType="emailAddress"
                            placeholder="Nombre de usuario"
                            placeholderTextColor="grey"
                            autoCapitalize="none"
                            renderToHardwareTextureAndroid
                            onChangeText={userInputHandler}
                            cursorColor="#9d4edd"
                        />
                    </View>
                    <Space height={15} />
                    <View>
                        <Text style={{ ...styles.inputLabel, color: inputColors.password }}>{inputColors.password === 'black' ? 'Ingrese su contraseña' : 'Se requiere una contraseña'}</Text>
                        <TextInput
                            style={styles.usernameInput}
                            textContentType="password"
                            secureTextEntry
                            placeholder="Contraseña"
                            placeholderTextColor="grey"
                            autoCapitalize="none"
                            renderToHardwareTextureAndroid
                            onChangeText={passwordInputHandler}
                            cursorColor="#9d4edd"
                            accessibilityLabel="Password"
                        />
                    </View>
                </View>
                <TouchableOpacity
                    style={styles.button}
                    onPress={handleSubmit}
                >
                    {
                        isLoading
                            ? <ActivityIndicator style={styles.buttonItem} size={24} color="white" />
                            : <Text style={{ ...styles.buttonItem, ...styles.textButton }}>Iniciar Sesion</Text>
                    }
                </TouchableOpacity>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#9d4edd',
    },
    logo: {
        width: 100,
        height: 100,
        bottom: 50,
    },
    form: {
        backgroundColor: '#FFF',
        paddingHorizontal: 25,
        borderRadius: 20,
        justifyContent: 'space-evenly',
    },
    header: {
        color: 'black',
        fontSize: 38,
        fontWeight: 'bold',
        textAlign: 'center',
    },
    button: {
        textAlign: 'center',
        alignSelf: 'center',
        justifyContent: 'center',
        marginTop: 40,
        backgroundColor: '#9d4edd',
        borderRadius: 10,
        paddingHorizontal: 10,
        width: 150,
        height: 50,
    },
    buttonItem: {
        color: 'white',
        margin: 10,
    },
    textButton: {
        fontSize: 18,
    },
    inputLabel: {
        left: 6,
        color: 'black',
        fontSize: 14,
        marginTop: 15,
        marginVertical: 5,
    },
    usernameInput: {
        color: 'black',
        borderWidth: 1,
        paddingVertical: 4,
        paddingLeft: 10,
        borderRadius: 15,
    },
});
