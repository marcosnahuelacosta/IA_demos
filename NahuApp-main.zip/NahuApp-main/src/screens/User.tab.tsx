import React, { useContext } from 'react';
import { Image, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { Card } from '../components/Card';
import { ImageContainer } from '../components/ImageContainer';
import { CustomTouchable } from '../components/CustomTouchable';
import { UserStackProps } from '../interfaces/Navigation';
import { UserContext } from '../context/UserContext';

export const User = ({ navigation }: UserStackProps) => {

    const { userData } = useContext(UserContext);
    const { width: widthD } = useWindowDimensions();

    return (
        <View style={styles.container}>
            <Card style={{ padding: 30, alignItems: 'center', justifyContent: 'space-around' }}>
                <View>
                    <ImageContainer>
                        <Image
                            source={{ uri: `https://api.dicebear.com/6.x/pixel-art-neutral/svg?seed=${userData.username}` }}
                            style={styles.userImage}
                        />
                    </ImageContainer>
                </View>
                <View>
                    <Text style={{ color: 'black', fontSize: 24 }}>{userData.username}</Text>
                    <Text style={{ fontSize: 18, marginTop: 10, color: 'grey' }} >45.581.112</Text>
                </View>
            </Card>
            <CustomTouchable
                style={{ width: widthD - 20, marginTop: 35 }}
                title="Configuracion"
                handlerPress={() => navigation.navigate('Settings')}
            />

            <CustomTouchable
                style={{ width: widthD - 20, marginTop: 25 }}
                title="SOPORTE TECNICO"
            />

            <Text style={{ fontSize: 12, marginTop: 30, color: 'grey' }}>CryptoPagos v1.0.0</Text>
            <Text style={{ color: 'black', marginTop: 20 }}>CryptoVerse ® 2023</Text>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        backgroundColor: 'white',
        marginTop: 20,
    },
    userImage: {
        width: 100,
        height: 100,
        backgroundColor: '#FFF',
        borderRadius: 50,
    },
});
