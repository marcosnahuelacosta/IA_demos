import React, { useContext } from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { Props } from '../interfaces/Navigation';
import { UserContext } from '../context/UserContext';

export const Settings = ({ navigation }: Props) => {

    const { logOut } = useContext(UserContext);

    const handlePress = async () => {
        await logOut();
        navigation.reset({ routes: [{ name: 'Login' }] });
    };

    return (
        <View style={styles.container}>
            <Text style={styles.text}>Settings</Text>

            <TouchableOpacity style={styles.button} onPress={handlePress}>
                <Text style={styles.textButton}>Cerrar Sesion</Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
    },
    button: {
        backgroundColor: 'grey',
        borderRadius: 10,
    },
    textButton: {
        color: 'white',
        padding: 10,
    },
    text: {
        color: 'black',
    },
});
