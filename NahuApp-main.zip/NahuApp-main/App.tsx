import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { StackNavigator } from './src/navigator/Stack';
import { UserContextProvider } from './src/context/UserContext';


export const App = () => {

  return (
    <UserContextProvider>
      <NavigationContainer>
        <StackNavigator />
      </NavigationContainer>
    </UserContextProvider>
  );
};
